// src/pages/Manage.jsx
function Order() {
  return (
    <div>
      <h2>🛠️ New Order</h2>
      <p>This will include inventory, menu management, and staff accounts.</p>
    </div>
  );
}

export default Order;
