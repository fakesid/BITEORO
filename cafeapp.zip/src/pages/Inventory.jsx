import { useEffect, useState } from "react";
import { db } from "../firebase";
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  addDoc,
  deleteDoc,
} from "firebase/firestore";

export default function Inventory() {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: "", quantity: "", unit: "pcs", min: 5 });

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "inventory"), (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setItems(list);
    });
    return () => unsub();
  }, []);

  const addItem = async () => {
    if (!newItem.name || !newItem.quantity) return;
    await addDoc(collection(db, "inventory"), {
      ...newItem,
      quantity: parseFloat(newItem.quantity),
      min: parseFloat(newItem.min || 0),
    });
    setNewItem({ name: "", quantity: "", unit: "pcs", min: 5 });
  };

  const adjustQty = async (id, delta) => {
    const ref = doc(db, "inventory", id);
    const item = items.find((i) => i.id === id);
    const newQty = Math.max(0, (item.quantity || 0) + delta);
    await updateDoc(ref, { quantity: newQty });
  };

  const deleteItem = async (id) => {
    if (window.confirm("Delete this inventory item?")) {
      await deleteDoc(doc(db, "inventory", id));
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold text-sienna mb-4">📦 Inventory</h2>

      <div className="flex flex-wrap items-center gap-4 mb-6">
        <input
          type="text"
          placeholder="Item name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
          className="px-4 py-2 rounded bg-rich-black border border-sienna text-papaya-whip"
        />
        <input
          type="number"
          placeholder="Quantity"
          value={newItem.quantity}
          onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })}
          className="px-4 py-2 rounded bg-rich-black border border-sienna text-papaya-whip w-28"
        />
        <select
          value={newItem.unit}
          onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
          className="px-3 py-2 bg-rich-black border border-sienna text-papaya-whip rounded"
        >
          <option value="pcs">pcs</option>
          <option value="kg">kg</option>
          <option value="L">L</option>
        </select>
        <input
          type="number"
          placeholder="Min Threshold"
          value={newItem.min}
          onChange={(e) => setNewItem({ ...newItem, min: e.target.value })}
          className="px-4 py-2 rounded bg-rich-black border border-sienna text-papaya-whip w-32"
        />
        <button
          onClick={addItem}
          className="px-4 py-2 bg-caribbean-current text-black rounded hover:opacity-90"
        >
          ➕ Add
        </button>
      </div>

      <div className="space-y-3">
        {items.map((item) => (
          <div
            key={item.id}
            className={`flex justify-between items-center p-4 rounded-lg border ${
              item.quantity <= item.min ? "border-red-500" : "border-sienna/30"
            } bg-rich-black`}
          >
            <div>
              <div className="text-papaya-whip font-semibold">{item.name}</div>
              <div className="text-sm text-sienna">
                {item.quantity} {item.unit} — Min: {item.min} {item.unit}
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => adjustQty(item.id, -1)}
                className="px-3 py-1 bg-sienna/30 text-white rounded-full"
              >
                –
              </button>
              <button
                onClick={() => adjustQty(item.id, 1)}
                className="px-3 py-1 bg-sienna/30 text-white rounded-full"
              >
                +
              </button>
              <button
                onClick={() => deleteItem(item.id)}
                className="px-3 py-1 bg-red-600 text-white text-xs rounded-full hover:bg-red-700"
              >
                🗑
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
