import { useState, useEffect } from "react";
import DashboardSummary from "../components/DashboardSummary";
import ImprovedOrderPage from "./ImprovedOrderPage";  // since it's inside pages/

import RecentOrders from "../components/RecentOrders";

function Home() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  // Lock scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = showOrderForm ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [showOrderForm]);

  return (
    <div>
      <div style={{ display: "flex", gap: "24px" }}>
        {/* Left side: summary and new order */}
        <div style={{ flex: 2 }}>

          <DashboardSummary />

          <div style={{ marginTop: 20 }}>
            <button onClick={() => setShowOrderForm(true)}>➕ New Order</button>
          </div>
        </div>

        {/* Right side: recent orders tab */}
        <div style={{ flex: 1, marginTop: "0px" }}>
          <RecentOrders />
        </div>
      </div>

      {/* Modal popup with OrderPage */}
{showOrderForm && (
  <div className="mt-6">
    <ImprovedOrderPage onOrderPlaced={() => setShowOrderForm(false)} />
  </div>
)}


    </div>
  );
}

export default Home;
