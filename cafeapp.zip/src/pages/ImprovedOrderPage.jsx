import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";

export default function ImprovedOrderPage({ onOrderPlaced }) {
  const [menuItems, setMenuItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paid, setPaid] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    setMenuItems(items);
  };

  const filteredItems = menuItems.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToCart = (item) => {
    const exists = cart.find((i) => i.id === item.id);
    if (exists) {
      setCart(
        cart.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      );
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const decreaseQty = (id) => {
    const item = cart.find((i) => i.id === id);
    if (item.quantity === 1) {
      removeFromCart(id);
    } else {
      setCart(
        cart.map((i) =>
          i.id === id ? { ...i, quantity: item.quantity - 1 } : i
        )
      );
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const getTotal = () =>
    cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const placeOrder = async () => {
    if (cart.length === 0) {
      setMessage("❌ Cart is empty");
      return;
    }

    try {
      const docRef = await addDoc(collection(db, "orders"), {
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        paymentMode: paid ? "cash" : null,
        createdAt: serverTimestamp(),
        status: "new",
      });

      setCart([]);
      setCustomerName("");
      setCustomerPhone("");
      setPaid(false);
      setSearchTerm("");
      setMessage(`✅ Order placed. ID: ${docRef.id}`);

      if (onOrderPlaced) onOrderPlaced();
    } catch (err) {
      setMessage("❌ Failed: " + err.message);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow border">
      <h2 className="text-xl font-bold mb-4">🍽️ New Order</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Menu Section */}
        <div className="flex flex-col">
          <label className="mb-1 font-semibold">Search menu...</label>
          <input
            type="text"
            placeholder="Search menu..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mb-3 px-3 py-2 border rounded-md text-sm"
          />
          <div className="space-y-3 overflow-y-auto max-h-[420px] pr-1">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="flex justify-between items-center px-4 py-3 bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl transition"
              >
                <div>
                  <div className="text-sm font-semibold">{item.name}</div>
                  <div className="text-xs text-zinc-400">₹{item.price}</div>
                </div>
                <button
                  onClick={() => addToCart(item)}
                  className="bg-orange-500 hover:bg-orange-600 w-8 h-8 flex items-center justify-center rounded-full text-white"
                >
                  ➕
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Cart Section */}
        <div className="space-y-2">
          <h3 className="text-lg font-semibold mb-2">🛒 Cart</h3>
          {cart.map((item) => (
            <div
              key={item.id}
              className="flex justify-between items-center border p-3 rounded-lg"
            >
              <span>
                {item.name} — ₹{item.price} × {item.quantity}
              </span>
              <div className="flex gap-1">
                <button
                  onClick={() => decreaseQty(item.id)}
                  className="px-2 py-1 text-sm bg-zinc-200 rounded"
                >
                  ➖
                </button>
                <button
                  onClick={() => addToCart(item)}
                  className="px-2 py-1 text-sm bg-zinc-200 rounded"
                >
                  ➕
                </button>
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="px-2 py-1 text-sm bg-red-500 text-white rounded"
                >
                  ❌
                </button>
              </div>
            </div>
          ))}

          {cart.length > 0 && (
            <>
              <h4 className="mt-4 font-semibold">Total: ₹{getTotal()}</h4>
              <input
                type="text"
                placeholder="Customer name (optional)"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-2 mt-2 rounded-md border"
              />
              <input
                type="text"
                placeholder="Phone (optional)"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-2 mt-2 rounded-md border"
              />
              <label className="flex items-center gap-2 mt-2 text-sm">
                <input
                  type="checkbox"
                  checked={paid}
                  onChange={(e) => setPaid(e.target.checked)}
                />
                Mark as Paid
              </label>
              <button
                onClick={placeOrder}
                className="w-full mt-4 bg-orange-500 hover:bg-orange-600 py-2 rounded-md text-white font-semibold"
              >
                ✅ Place Order
              </button>
            </>
          )}
        </div>
      </div>

      {message && <p className="mt-4 text-sm text-orange-500">{message}</p>}
    </div>
  );
}
