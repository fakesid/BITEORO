import { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, onSnapshot } from "firebase/firestore";

export default function Customers() {
  const [orders, setOrders] = useState([]);
  const [expandedPhone, setExpandedPhone] = useState(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "orders"), (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setOrders(data);
    });
    return () => unsub();
  }, []);

  const customers = orders.reduce((acc, order) => {
    const phone = order.customerPhone || "Unknown";
    if (!acc[phone]) {
      acc[phone] = {
        phone,
        name: order.customerName || "",
        orders: [],
        total: 0,
        lastSeen: null,
      };
    }
    acc[phone].orders.push(order);
    acc[phone].total += order.total || 0;
    acc[phone].lastSeen = order.createdAt;
    return acc;
  }, {});

  const sortedCustomers = Object.values(customers).sort(
    (a, b) => (b.lastSeen?.seconds || 0) - (a.lastSeen?.seconds || 0)
  );

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold text-sienna mb-4">👥 Customers</h2>

      <div className="space-y-4">
        {sortedCustomers.map((cust) => (
          <div
            key={cust.phone}
            className="bg-rich-black border border-sienna/30 rounded-lg p-4 cursor-pointer hover:border-sienna"
            onClick={() =>
              setExpandedPhone(expandedPhone === cust.phone ? null : cust.phone)
            }
          >
            <div className="flex justify-between items-center">
              <div>
                <div className="font-bold text-papaya-whip">
                  {cust.name || "(No Name)"} — {cust.phone}
                </div>
                <div className="text-sm text-sienna">
                  {cust.orders.length} orders • ₹{cust.total} spent
                </div>
              </div>
              <div className="text-xs text-papaya-whip">
                🕒 Last: {new Date(cust.lastSeen?.seconds * 1000).toLocaleDateString()}
              </div>
            </div>

            {expandedPhone === cust.phone && (
              <div className="mt-3 text-sm text-papaya-whip border-t border-sienna/30 pt-3 space-y-2">
                {cust.orders.slice(0, 5).map((o) => (
                  <div key={o.id} className="flex justify-between">
                    <span className="text-caribbean-current">#{o.id.slice(-4)}</span>
                    <span>{new Date(o.createdAt?.seconds * 1000).toLocaleString()}</span>
                    <span>₹{o.total}</span>
                    <span>{o.paid ? "✅" : "❌"}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
