import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
} from "firebase/firestore";

function MenuManager() {
  const [menuItems, setMenuItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: "", price: "", inStock: true });
  const [editingItemId, setEditingItemId] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    setMenuItems(items);
  };

  const handleAddItem = async () => {
    if (!newItem.name || !newItem.price) return;
    await addDoc(collection(db, "menu"), {
      ...newItem,
      price: parseFloat(newItem.price),
      inStock: !!newItem.inStock,
    });
    setNewItem({ name: "", price: "", inStock: true });
    fetchMenu();
  };

  const handleDelete = async (id) => {
    await deleteDoc(doc(db, "menu", id));
    fetchMenu();
  };

  const handleUpdate = async (id, updated) => {
    await updateDoc(doc(db, "menu", id), updated);
    setEditingItemId(null);
    fetchMenu();
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold text-sienna mb-4">📋 Menu Manager</h2>

      {/* Add New Item */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        <input
          type="text"
          placeholder="Item name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
          className="px-4 py-2 rounded bg-rich-black border border-sienna text-papaya-whip"
        />
        <input
          type="number"
          placeholder="Price"
          value={newItem.price}
          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
          className="px-4 py-2 rounded bg-rich-black border border-sienna text-papaya-whip"
        />
        <div
          onClick={() => setNewItem((prev) => ({ ...prev, inStock: !prev.inStock }))}
          className={`w-12 h-6 rounded-full flex items-center px-1 cursor-pointer ${
            newItem.inStock ? "bg-green-500" : "bg-red-500"
          }`}
        >
          <div
            className={`w-4 h-4 rounded-full bg-white transition-all ${
              newItem.inStock ? "translate-x-6" : ""
            }`}
          ></div>
        </div>
        <button
          onClick={handleAddItem}
          className="px-4 py-2 bg-caribbean-current text-black rounded hover:opacity-90"
        >
          ➕ Add Item
        </button>
      </div>

      <hr className="border-sienna/30 mb-4" />

      <h3 className="text-lg font-semibold mb-3 text-sienna">📦 Menu Items</h3>
      <div className="space-y-3">
        {menuItems.map((item) => (
          <div
            key={item.id}
            className="flex justify-between items-center p-4 rounded-lg bg-rich-black border border-sienna/30"
          >
            {editingItemId === item.id ? (
              <>
                <div className="flex flex-col gap-2 flex-grow mr-4">
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) =>
                      setMenuItems((prev) =>
                        prev.map((i) =>
                          i.id === item.id ? { ...i, name: e.target.value } : i
                        )
                      )
                    }
                    className="px-3 py-1 rounded bg-sienna/10 text-papaya-whip"
                  />
                  <input
                    type="number"
                    value={item.price}
                    onChange={(e) =>
                      setMenuItems((prev) =>
                        prev.map((i) =>
                          i.id === item.id ? { ...i, price: e.target.value } : i
                        )
                      )
                    }
                    className="px-3 py-1 rounded bg-sienna/10 text-papaya-whip"
                  />
                </div>
                <div
                  onClick={() =>
                    setMenuItems((prev) =>
                      prev.map((i) =>
                        i.id === item.id
                          ? { ...i, inStock: !i.inStock }
                          : i
                      )
                    )
                  }
                  className={`w-12 h-6 rounded-full flex items-center px-1 cursor-pointer ${
                    item.inStock ? "bg-green-500" : "bg-red-500"
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-all ${
                      item.inStock ? "translate-x-6" : ""
                    }`}
                  ></div>
                </div>
                <button
                  onClick={() => handleUpdate(item.id, item)}
                  className="ml-2 px-3 py-1 text-xs bg-caribbean-current text-black rounded hover:opacity-90"
                >
                  💾 Save
                </button>
                <button
                  onClick={() => setEditingItemId(null)}
                  className="ml-1 px-3 py-1 text-xs bg-red-500 text-white rounded hover:bg-red-600"
                >
                  ❌ Cancel
                </button>
              </>
            ) : (
              <>
                <div className="text-papaya-whip text-sm flex flex-col gap-1">
                  <div className="flex items-center gap-2">
                    🍔 <span className="font-bold">{item.name}</span>
                    <span>— ₹{item.price}</span>
                    {item.inStock ? (
                      <span className="ml-2 text-green-400">✅ In Stock</span>
                    ) : (
                      <span className="ml-2 text-red-400">❌ Out of Stock</span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setEditingItemId(item.id)}
                    className="text-xs text-orange-300 hover:text-orange-500"
                  >
                    ✏️ Edit
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="text-xs text-red-400 hover:text-red-600"
                  >
                    🗑 Delete
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default MenuManager;
