import { useState, useEffect, useRef } from "react";
import Home from "./pages/Home";
import Customers from "./pages/Customers";
import History from "./pages/History";
import MenuManager from "./pages/MenuManager";
import Inventory from "./pages/Inventory";
import StaffAccounts from "./pages/StaffAccounts";
import ImprovedOrderPage from "./pages/ImprovedOrderPage";


const tabs = [
  { name: "Dashboard", component: <Home />, icon: "🏠" },
  { name: "Orders", component: <ImprovedOrderPage />, icon: "🧾" },
  { name: "Customers", component: <Customers />, icon: "👥" },
  { name: "History", component: <History />, icon: "📜" },
  { name: "Menu", component: <MenuManager />, icon: "🍽️" },
  { name: "Inventory", component: <Inventory />, icon: "📦" },
  { name: "Staff", component: <StaffAccounts />, icon: "🧑‍🍳" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState("Dashboard");
  const currentTab = tabs.find((tab) => tab.name === activeTab);

  return (
    <div className="flex h-screen bg-rich-black text-papaya-whip">
      {/* Sidebar */}

      <aside className="w-20 xl:w-60 bg-rich-black border-r border-sienna flex flex-col items-center xl:items-start py-4">
              <div className="w-full flex justify-center xl:justify-start px-4 mb-6">
  <div className="flex items-center gap-2 text-2xl font-bold text-black">
    <span>
      🍪Bite<span className="text-orange-500">OrO</span>
    </span>
  </div>
</div>


        {tabs.map((tab) => (
          <button
            key={tab.name}
            onClick={() => setActiveTab(tab.name)}
            className={`w-full flex items-center gap-2 px-4 py-3 text-sm hover:bg-sienna/20 transition ${
              activeTab === tab.name ? "bg-sienna/30" : ""
            }`}
          >
            <span className="text-lg">{tab.icon}</span>
            <span className="hidden xl:inline">{tab.name}</span>
          </button>
        ))}
      </aside>

      {/* Main Panel */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Row */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-sienna bg-rich-black">
          <div className="flex-1 max-w-xl mx-4">
            <input
              type="text"
              placeholder="Search orders, customers, menu..."
              className="w-full px-4 py-2 rounded-full bg-sienna/10 text-papaya-whip focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-sienna">Cafe Delight</span>
            <div className="w-8 h-8 rounded-full bg-caribbean-current"></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {currentTab?.component || <div>Coming soon...</div>}
        </div>
      </div>
    </div>
  );
}

// Placeholder exports for pages
export const pages = {
  Home: () => <div>Home Page</div>,
  Customers: () => <div>Customers Page</div>,
  History: () => <div>History Page</div>,
  MenuManager: () => <div>Menu Page</div>,
  Inventory: () => <div>Inventory Page</div>,
  StaffAccounts: () => <div>Staff Page</div>,
  ImprovedOrderPage: () => <div>Order Page</div>,
};
