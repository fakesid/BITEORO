import { useEffect, useState } from "react";
import { db } from "../firebase";
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";

function RecentOrders() {
  const [orders, setOrders] = useState([]);
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "orders"), (snapshot) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const all = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      const todayOrders = all.filter((o) => {
        const created = o.createdAt?.toDate?.() || new Date(o.createdAt);
        return created >= today;
      });

      setOrders(todayOrders.reverse());
    });

    return () => unsub();
  }, []);

  const togglePaid = async (id, currentStatus) => {
    const ref = doc(db, "orders", id);
    await updateDoc(ref, { paid: !currentStatus });
  };

  const deleteOrder = async (id) => {
    if (window.confirm("Delete this order?")) {
      await deleteDoc(doc(db, "orders", id));
    }
  };

  return (
    <div className="bg-sienna/10 p-4 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold mb-2 text-sienna flex items-center gap-1">
        🕒 Recent Orders
      </h3>
      <ul className="text-sm space-y-2">
        {orders.slice(0, 6).map((order) => (
          <li
            key={order.id}
            className="p-2 rounded-md bg-sienna/5 hover:bg-sienna/10 cursor-pointer"
            onClick={() =>
              setExpandedId(expandedId === order.id ? null : order.id)
            }
          >
            <div className="flex justify-between items-center text-sm font-medium">
              <span className="text-caribbean-current font-mono">
                #{order.id.slice(-4)}
              </span>
              <span>{order.customerName || "—"}</span>
              <span className="text-green-400">₹{order.total}</span>
              {order.paid && <span>✅</span>}
            </div>

            {expandedId === order.id && (
              <div className="mt-2 text-xs text-papaya-whip space-y-2">
                <div>
                  🕒{" "}
                  {new Date(
                    order.createdAt?.seconds * 1000
                  ).toLocaleTimeString()}
                </div>
                <div>
                  📦 Items:
                  <ul className="list-disc list-inside pl-4 mt-1 space-y-1">
                    {(order.items || []).map((item, idx) => (
                      <li key={idx}>
                        {item.quantity}x {item.name} — ₹
                        {item.price * item.quantity}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>💳 Method: {order.paymentMode || "—"}</div>

                <div className="flex gap-3 mt-2">
                  <button
                    className="px-3 py-1 bg-caribbean-current text-sm text-black rounded"
                    onClick={(e) => {
                      e.stopPropagation();
                      togglePaid(order.id, order.paid);
                    }}
                  >
                    {order.paid ? "Mark Unpaid" : "Mark Paid"}
                  </button>
                  <button
                    className="px-3 py-1 bg-red-600 text-sm text-white rounded"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteOrder(order.id);
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RecentOrders;
