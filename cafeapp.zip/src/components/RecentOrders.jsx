import { useEffect, useState } from "react";
import { db } from "../firebase";
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";

function RecentOrders() {
  const [orders, setOrders] = useState([]);
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "orders"), (snapshot) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const all = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      const todayOrders = all.filter((o) => {
        const created = o.createdAt?.toDate?.() || new Date(o.createdAt);
        return created >= today;
      });

      setOrders(todayOrders.reverse());
    });

    return () => unsub();
  }, []);

  const togglePaid = async (id, currentStatus) => {
    const ref = doc(db, "orders", id);
    await updateDoc(ref, { paid: !currentStatus });
  };

  const deleteOrder = async (id) => {
    if (window.confirm("Delete this order?")) {
      await deleteDoc(doc(db, "orders", id));
    }
  };

  return (
    <div className="bg-sienna/10 p-4 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold mb-3 text-sienna flex items-center gap-1">
        🕒 Recent Orders
      </h3>
      <ul className="space-y-3">
        {orders.slice(0, 6).map((order) => (
          <li
            key={order.id}
            className="p-3 rounded-lg bg-sienna/5 hover:bg-sienna/10 transition cursor-pointer border border-transparent hover:border-sienna/30"
            onClick={() =>
              setExpandedId(expandedId === order.id ? null : order.id)
            }
          >
            {/* Header row */}
            <div className="flex justify-between items-center text-sm font-medium">
              <div className="flex flex-col">
                <span className="text-caribbean-current font-mono">
                  #{order.id.slice(-4)}
                </span>
                <span className="text-xs text-papaya-whip">
                  {order.customerName || "—"}
                </span>
              </div>
              <span className="text-green-400 font-bold">₹{order.total}</span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full ${
                  order.paid
                    ? "bg-green-600 text-white"
                    : "bg-red-600 text-white"
                }`}
              >
                {order.paid ? "Paid" : "Unpaid"}
              </span>
            </div>

            {/* Expanded details */}
            {expandedId === order.id && (
              <div className="mt-4 px-3 py-2 bg-rich-black rounded-md border border-sienna/30 space-y-3 shadow-sm">
                <div className="flex items-center gap-2 text-papaya-whip text-sm">
                  🕒{" "}
                  <span>
                    {new Date(
                      order.createdAt?.seconds * 1000
                    ).toLocaleTimeString()}
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-papaya-whip mb-1 text-sm">
                    📦 <span>Items:</span>
                  </div>
                  <ul className="ml-5 list-disc space-y-1 text-papaya-whip text-sm">
                    {(order.items || []).map((item, idx) => (
                      <li key={idx}>
                        <span className="font-light">{item.quantity}x</span>{" "}
                        <span className="font-medium">{item.name}</span> —{" "}
                        <span className="font-semibold">
                          ₹{item.price * item.quantity}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-center gap-2 text-sm text-papaya-whip">
                  💳 <span className="text-gray-400">Method:</span>{" "}
                  <span className="font-semibold">
                    {order.paymentMode || "—"}
                  </span>
                </div>

                <div className="flex gap-3 mt-2">
                  <button
                    className="px-3 py-1 bg-caribbean-current text-black text-xs rounded-full hover:opacity-90 flex items-center gap-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      togglePaid(order.id, order.paid);
                    }}
                  >
                    📝 {order.paid ? "Mark Unpaid" : "Mark Paid"}
                  </button>
                  <button
                    className="px-3 py-1 bg-red-600 text-white text-xs rounded-full hover:bg-red-700 flex items-center gap-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteOrder(order.id);
                    }}
                  >
                    🗑 Delete
                  </button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RecentOrders;
