// ✅ Final OrderPage.js — Wrapped in Centered Modal Style (Tailwind)

import React, { useState, useEffect } from "react";
import { db } from "./firebase";
import OrderBill from "./OrderBill";
import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";

function OrderPage({ onOrderPlaced }) {
  const [menuItems, setMenuItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paid, setPaid] = useState(false);
  const [message, setMessage] = useState("");
  const [lastOrder, setLastOrder] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    setMenuItems(items);
  };

  const filteredItems = menuItems.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToCart = (item) => {
    const exists = cart.find((i) => i.id === item.id);
    if (exists) {
      setCart(
        cart.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      );
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const decreaseQty = (id) => {
    const item = cart.find((i) => i.id === id);
    if (item.quantity === 1) {
      removeFromCart(id);
    } else {
      setCart(
        cart.map((i) =>
          i.id === id ? { ...i, quantity: item.quantity - 1 } : i
        )
      );
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const getTotal = () =>
    cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const placeOrder = async () => {
    if (cart.length === 0) {
      setMessage("❌ Cart is empty");
      return;
    }

    try {
      const docRef = await addDoc(collection(db, "orders"), {
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        paymentMode: paid ? "cash" : null,
        createdAt: serverTimestamp(),
        status: "new",
      });

      setLastOrder({
        id: docRef.id,
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        createdAt: Timestamp.now(),
      });

      setCart([]);
      setCustomerName("");
      setCustomerPhone("");
      setPaid(false);
      setSearchTerm("");
      setMessage(`✅ Order placed. ID: ${docRef.id}`);

      if (onOrderPlaced) onOrderPlaced();
    } catch (err) {
      setMessage("❌ Failed: " + err.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
      <div className="w-[420px] max-h-[90vh] overflow-y-auto bg-[#1c1c1c] text-white p-6 rounded-xl shadow-xl">
        <input
          type="text"
          placeholder="Search menu item..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-2 mb-4 rounded border border-gray-700 bg-[#111] text-white"
        />

        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="flex justify-between items-center mb-2 border border-gray-700 p-2 rounded"
          >
            <span>
              {item.name} — ₹{item.price}
            </span>
            <button
              onClick={() => addToCart(item)}
              className="bg-orange-500 hover:bg-orange-600 text-white px-3 py-1 rounded"
            >
              ➕
            </button>
          </div>
        ))}

        <h4 className="mt-4 font-semibold">🛒 Cart</h4>
        {cart.map((item) => (
          <div
            key={item.id}
            className="flex justify-between items-center mb-2"
          >
            <span>
              {item.name} — ₹{item.price} × {item.quantity}
            </span>
            <div className="space-x-1">
              <button onClick={() => decreaseQty(item.id)}>➖</button>
              <button onClick={() => addToCart(item)}>➕</button>
              <button onClick={() => removeFromCart(item.id)}>❌</button>
            </div>
          </div>
        ))}

        {cart.length > 0 && (
          <>
            <h4 className="mt-2">Total: ₹{getTotal()}</h4>
            <input
              type="text"
              placeholder="Customer name (optional)"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full my-2 p-2 rounded border border-gray-600 bg-[#111] text-white"
            />
            <input
              type="text"
              placeholder="Phone (optional)"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              className="w-full mb-2 p-2 rounded border border-gray-600 bg-[#111] text-white"
            />
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={paid}
                onChange={(e) => setPaid(e.target.checked)}
              />
              <span>Mark as Paid</span>
            </label>
            <button
              onClick={placeOrder}
              className="mt-4 w-full bg-orange-500 hover:bg-orange-600 text-white py-2 rounded"
            >
              ✅ Place Order
            </button>
          </>
        )}

        {message && <p className="mt-3 text-sm text-red-400">{message}</p>}
      </div>
    </div>
  );
}

export default OrderPage;