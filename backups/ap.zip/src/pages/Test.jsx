// src/pages/Test.jsx
import React from "react";

export default function Test() {
  return (
    <div className="h-screen flex items-center justify-center bg-black">
      <div className="text-4xl font-bold text-orange-500 p-6 rounded-lg shadow-lg border border-orange-500">
        ✅ Tailwind is working!
      </div>
    </div>
  );
}
