
// src/pages/ImprovedOrderPage.jsx
import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";

function ImprovedOrderPage({ onOrderPlaced }) {
  const [menuItems, setMenuItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paid, setPaid] = useState(false);
  const [message, setMessage] = useState("");
  const [lastOrder, setLastOrder] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    setMenuItems(items);
  };

  const filteredItems = menuItems.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToCart = (item) => {
    const exists = cart.find((i) => i.id === item.id);
    if (exists) {
      setCart(
        cart.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      );
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const decreaseQty = (id) => {
    const item = cart.find((i) => i.id === id);
    if (item.quantity === 1) {
      removeFromCart(id);
    } else {
      setCart(
        cart.map((i) =>
          i.id === id ? { ...i, quantity: item.quantity - 1 } : i
        )
      );
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const getTotal = () =>
    cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const placeOrder = async () => {
    if (cart.length === 0) {
      setMessage("❌ Cart is empty");
      return;
    }

    try {
      const docRef = await addDoc(collection(db, "orders"), {
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        paymentMode: paid ? "cash" : null,
        createdAt: serverTimestamp(),
        status: "new",
      });

      setLastOrder({
        id: docRef.id,
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        createdAt: Timestamp.now(),
      });

      setCart([]);
      setCustomerName("");
      setCustomerPhone("");
      setPaid(false);
      setSearchTerm("");
      setMessage(`✅ Order placed. ID: ${docRef.id}`);

      if (onOrderPlaced) onOrderPlaced();
    } catch (err) {
      setMessage("❌ Failed: " + err.message);
    }
  };

  return (
    <div className="w-[420px] min-h-[500px] max-h-[80vh] overflow-y-auto bg-zinc-900 text-white p-6 rounded-2xl shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <input
          type="text"
          placeholder="Search menu item..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1 p-2 rounded-md bg-zinc-800 text-white border border-zinc-700"
        />
        <button onClick={() => setSearchTerm("")} className="ml-2 text-white">✖</button>
      </div>

      <div className="flex flex-col gap-2">
        {filteredItems.map((item) => (
          <div key={item.id} className="flex justify-between items-center bg-zinc-800 p-2 rounded-lg">
            <span>{item.name} — ₹{item.price}</span>
            <button
              onClick={() => addToCart(item)}
              className="bg-orange-500 hover:bg-orange-600 px-3 py-1 rounded text-white"
            >
              ➕
            </button>
          </div>
        ))}
      </div>

      <h4 className="mt-4 font-semibold">🛒 Cart</h4>
      <div className="flex flex-col gap-2">
        {cart.map((item) => (
          <div key={item.id} className="flex justify-between items-center">
            <span>
              {item.name} — ₹{item.price} × {item.quantity}
            </span>
            <div className="flex gap-2">
              <button onClick={() => decreaseQty(item.id)} className="bg-orange-500 px-2 rounded text-white">➖</button>
              <button onClick={() => addToCart(item)} className="bg-orange-500 px-2 rounded text-white">➕</button>
              <button onClick={() => removeFromCart(item.id)} className="bg-orange-500 px-2 rounded text-white">❌</button>
            </div>
          </div>
        ))}
      </div>

      {cart.length > 0 && (
        <>
          <h4 className="mt-4 font-semibold">Total: ₹{getTotal()}</h4>
          <input
            type="text"
            placeholder="Customer name (optional)"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            className="w-full p-2 mt-2 rounded-md bg-zinc-800 text-white border border-zinc-700"
          />
          <input
            type="text"
            placeholder="Phone (optional)"
            value={customerPhone}
            onChange={(e) => setCustomerPhone(e.target.value)}
            className="w-full p-2 mt-2 rounded-md bg-zinc-800 text-white border border-zinc-700"
          />
          <label className="flex items-center gap-2 mt-3">
            <input
              type="checkbox"
              checked={paid}
              onChange={(e) => setPaid(e.target.checked)}
            />
            Mark as Paid
          </label>
          <button
            onClick={placeOrder}
            className="w-full mt-4 bg-orange-500 hover:bg-orange-600 text-white py-2 rounded-md"
          >
            ✅ Place Order
          </button>
        </>
      )}

      {message && <p className="mt-3 text-sm text-orange-400">{message}</p>}
    </div>
  );
}

export default ImprovedOrderPage;
