import { useState, useEffect } from "react";
import DashboardSummary from "../components/DashboardSummary";
import Modal from "../components/Modal";
import OrderPage from "../OrderPage";
import RecentOrders from "../components/RecentOrders";

function Home() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  // Lock scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = showOrderForm ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [showOrderForm]);

  return (
    <div>
      <div style={{ display: "flex", gap: "24px" }}>
        {/* Left side: summary and new order */}
        <div style={{ flex: 2 }}>
          <input
            type="text"
            placeholder="Search orders, customers, dates..."
            style={{
              padding: "10px",
              borderRadius: "5px",
              border: "1px solid #ccc",
              width: "100%",
              marginBottom: "20px"
            }}
          />

          <DashboardSummary />

          <div style={{ marginTop: 20 }}>
            <button onClick={() => setShowOrderForm(true)}>➕ New Order</button>
          </div>
        </div>

        {/* Right side: recent orders tab */}
        <div style={{ flex: 1 }}>
          <RecentOrders />
        </div>
      </div>

      {/* Modal popup with OrderPage */}
      {showOrderForm && (
        <Modal onClose={() => setShowOrderForm(false)}>
          <OrderPage onOrderPlaced={() => setShowOrderForm(false)} />
        </Modal>
      )}

      {/* Floating button */}
      <button
        onClick={() => setShowOrderForm(true)}
        style={{
          position: "fixed",
          bottom: "30px",
          right: "30px",
          backgroundColor: "#FF7D00",
          color: "#fff",
          border: "none",
          padding: "14px 18px",
          borderRadius: "50%",
          fontSize: "22px",
          cursor: "pointer",
          boxShadow: "0 4px 12px rgba(0,0,0,0.4)",
          zIndex: 100
        }}
      >
        ➕
      </button>
    </div>
  );
}

export default Home;
