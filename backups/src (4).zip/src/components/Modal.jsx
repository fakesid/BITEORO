import React from "react";

function Modal({ children, onClose }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-[#1e1e1e] p-6 rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex justify-end">
          <button onClick={onClose} className="text-white text-xl">❌</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export default Modal;
