// src/App.js
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Order from "./pages/Order";
import History from "./pages/History";
import Manage from "./pages/Manage";
import Customers from "./pages/Customers";

function App() {
  return (
    <Router>
      <div style={{ display: "flex" }}>
        <aside style={{ width: "200px", padding: "20px", background: "#f5f5f5" }}>
          <nav style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <Link to="/">🏠 Home</Link>
            <Link to="/order">🛒 New Order</Link>
            <Link to="/history">📜 Order History</Link>
            <Link to="/manage">🛠️ Manage</Link>
            <Link to="/customers">👥 Customers</Link>
          </nav>
        </aside>

        <main style={{ flexGrow: 1, padding: "20px" }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/order" element={<Order />} />
            <Route path="/history" element={<History />} />
            <Route path="/manage" element={<Manage />} />
            <Route path="/customers" element={<Customers />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
