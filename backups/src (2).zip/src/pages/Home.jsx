import { useState } from "react";
import OrderPage from "../OrderPage";
import DashboardSummary from "../components/DashboardSummary";

function Home() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
      {/* 🔍 Search */}
      <input
        type="text"
        placeholder="Search orders, customers, dates..."
        style={{
          padding: "10px",
          borderRadius: "5px",
          border: "1px solid #ccc",
          width: "100%",
        }}
      />

      {/* 📊 Today’s Summary comes first now */}
      <DashboardSummary />

      {/* ➕ New Order Section */}
      <div>
        <button onClick={() => setShowOrderForm(!showOrderForm)}>
          {showOrderForm ? "❌ Cancel New Order" : "➕ New Order"}
        </button>
        {showOrderForm && (
          <div
            style={{
              border: "1px solid #ccc",
              padding: "20px",
              marginTop: "10px",
            }}
          >
            <OrderPage onOrderPlaced={() => setShowOrderForm(false)} />
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;
