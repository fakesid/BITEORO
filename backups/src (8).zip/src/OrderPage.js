import React, { useState, useEffect } from "react";
import { db } from "./firebase";
import {
  collection,
  getDocs,
  addDoc,
  Timestamp,
} from "firebase/firestore";

export default function OrderPage({ onOrderPlaced }) {
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState({});
  const [customer, setCustomer] = useState({ name: "", note: "" });

  useEffect(() => {
    const fetchMenu = async () => {
      const snapshot = await getDocs(collection(db, "menu"));
      setMenu(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchMenu();
  }, []);

  const addItem = (item) => {
    setCart(prev => {
      const existing = prev[item.id];
      return {
        ...prev,
        [item.id]: { ...item, qty: existing ? existing.qty + 1 : 1 }
      };
    });
  };

  const changeQty = (id, delta) => {
    setCart(prev => {
      const updated = { ...prev };
      if (!updated[id]) return prev;
      updated[id].qty += delta;
      if (updated[id].qty <= 0) delete updated[id];
      return updated;
    });
  };

  const getTotal = () =>
    Object.values(cart).reduce((sum, item) => sum + item.qty * item.price, 0);

  const handlePlaceOrder = async () => {
    if (!customer.name || Object.keys(cart).length === 0) return;
    const order = {
      customer: customer.name,
      note: customer.note,
      items: Object.values(cart),
      paid: true,
      total: getTotal(),
      createdAt: Timestamp.now(),
    };
    await addDoc(collection(db, "orders"), order);
    setCart({});
    setCustomer({ name: "", note: "" });
    onOrderPlaced?.();
  };

  return (
    <div className="max-w-6xl mx-auto mt-8 p-4 grid grid-cols-1 md:grid-cols-2 gap-6 text-white">
      
      {/* Left: Menu List */}
      <div className="bg-zinc-900 p-4 rounded-xl shadow-lg">
        <input
          type="text"
          placeholder="🔍 Search items..."
          className="w-full mb-4 px-3 py-2 bg-zinc-800 rounded text-sm"
        />
        <div className="space-y-3">
          {menu.map(item => (
            <div key={item.id} className="flex justify-between items-center bg-zinc-800 px-4 py-2 rounded">
              <span className="text-sm font-medium truncate">{item.name}</span>
              <button
                onClick={() => addItem(item)}
                className="bg-orange-500 hover:bg-orange-600 px-3 py-1 rounded text-sm"
              >
                Add
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Right: Cart & Info */}
      <div className="bg-zinc-900 p-4 rounded-xl shadow-lg flex flex-col h-full">
        <h3 className="text-lg font-semibold mb-3">Cart</h3>

        {/* Scrollable Cart List */}
        <div className="overflow-y-auto max-h-60 space-y-2 pr-1 mb-4">
          {Object.values(cart).map(item => (
            <div key={item.id} className="flex justify-between items-center bg-zinc-800 px-3 py-2 rounded">
              <span className="truncate w-32">{item.name}</span>
              <div className="flex items-center gap-2">
                <button onClick={() => changeQty(item.id, -1)} className="px-2 bg-zinc-700 rounded">−</button>
                <span>{item.qty}</span>
                <button onClick={() => changeQty(item.id, 1)} className="px-2 bg-zinc-700 rounded">+</button>
              </div>
              <span>₹{item.qty * item.price}</span>
            </div>
          ))}
        </div>

        {/* Customer Info */}
        <div className="space-y-2 mb-4">
          <input
            type="text"
            placeholder="Customer Name"
            value={customer.name}
            onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
            className="w-full px-3 py-2 rounded bg-zinc-800 text-sm"
          />
          <input
            type="text"
            placeholder="Customer Note / Uber"
            value={customer.note}
            onChange={(e) => setCustomer({ ...customer, note: e.target.value })}
            className="w-full px-3 py-2 rounded bg-zinc-800 text-sm"
          />
        </div>

        {/* Order Summary */}
        <div className="border-t border-zinc-700 pt-3 mt-auto">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>₹{getTotal()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Tax</span>
            <span>₹0</span>
          </div>
          <div className="flex justify-between font-bold mt-1 text-base">
            <span>Total</span>
            <span>₹{getTotal()}</span>
          </div>
          <button
            onClick={handlePlaceOrder}
            className="w-full mt-4 bg-green-600 hover:bg-green-700 py-2 rounded text-white font-semibold"
          >
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
}
