// src/App.js
import { useState, useRef, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Order from "./pages/Order";
import History from "./pages/History";
import Manage from "./pages/Manage";
import Customers from "./pages/Customers";
import './index.css'; // ensure this is included

function App() {
    const [showDropdown, setShowDropdown] = useState(false);
const dropdownRef = useRef();

useEffect(() => {
  const handleClickOutside = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setShowDropdown(false);
    }
  };
  document.addEventListener("mousedown", handleClickOutside);
  return () => {
    document.removeEventListener("mousedown", handleClickOutside);
  };
}, []);

  return (
    <Router>


      <div style={{ display: "flex" }}>
        {/* Sidebar */}
        <aside className="sidebar">
     <div
  style={{
    fontFamily: "'Inter', sans-serif",
    fontSize: "28px",
    fontWeight: 800,
    letterSpacing: "0.5px",
    color: "#fff",
    textAlign: "left",
    marginBottom: "30px",
    paddingLeft: "16px",
    lineHeight: "1.4",
  }}
>
  🍪 <span style={{ color: "#fff" }}>Bite</span><span style={{ color: "#FF7D00" }}>OrO</span>
</div>

          <Link to="/">🏠 Home</Link>
          <Link to="/order">🛒 New Order</Link>
          <Link to="/history">📜 Order History</Link>
          <Link to="/manage">🛠️ Manage</Link>
          <Link to="/customers">👥 Customers</Link>
        </aside>
<div style={{ position: "absolute", top: "24px", right: "32px", zIndex: 100 }} ref={dropdownRef}>
  <img
    src="/profile.png"
    alt="Profile"
    title="Profile"
    style={{
      width: "40px",
      height: "40px",
      borderRadius: "50%",
      border: "2px solid #FF7D00",
      cursor: "pointer",
      objectFit: "cover"
    }}
    onClick={() => setShowDropdown(!showDropdown)}
  />

  {showDropdown && (
    <div style={{
      position: "absolute",
      top: "50px",
      right: "0",
      backgroundColor: "#1e1e1e",
      border: "1px solid #444",
      borderRadius: "8px",
      padding: "8px 0",
      width: "160px",
      boxShadow: "0 4px 12px rgba(0,0,0,0.5)"
    }}>
      <div style={{ padding: "10px 16px", color: "#fff", cursor: "pointer" }}>👤 Profile</div>
      <div style={{ padding: "10px 16px", color: "#fff", cursor: "pointer" }}>⚙️ Settings</div>
      <div style={{ padding: "10px 16px", color: "#fff", cursor: "pointer" }}>🚪 Logout</div>
    </div>
  )}
</div>


        {/* Main Content */}
        <main className="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/order" element={<Order />} />
            <Route path="/history" element={<History />} />
            <Route path="/manage" element={<Manage />} />
            <Route path="/customers" element={<Customers />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
