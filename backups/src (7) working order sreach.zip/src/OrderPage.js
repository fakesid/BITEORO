import React, { useState, useEffect } from "react";
import { db } from "./firebase";
import OrderBill from "./OrderBill";
import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";

function OrderPage({ onOrderPlaced }) {
  const [menuItems, setMenuItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paid, setPaid] = useState(false);
  const [message, setMessage] = useState("");
  const [lastOrder, setLastOrder] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    setMenuItems(items);
  };

  const filteredItems = menuItems.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToCart = (item) => {
    const exists = cart.find((i) => i.id === item.id);
    if (exists) {
      setCart(
        cart.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      );
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const decreaseQty = (id) => {
    const item = cart.find((i) => i.id === id);
    if (item.quantity === 1) {
      removeFromCart(id);
    } else {
      setCart(
        cart.map((i) =>
          i.id === id ? { ...i, quantity: item.quantity - 1 } : i
        )
      );
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const getTotal = () =>
    cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const placeOrder = async () => {
    if (cart.length === 0) {
      setMessage("❌ Cart is empty");
      return;
    }

    try {
      const docRef = await addDoc(collection(db, "orders"), {
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        paymentMode: paid ? "cash" : null,
        createdAt: serverTimestamp(),
        status: "new",
      });

      setLastOrder({
        id: docRef.id,
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        createdAt: Timestamp.now(),
      });

      setCart([]);
      setCustomerName("");
      setCustomerPhone("");
      setPaid(false);
      setSearchTerm("");
      setMessage(`✅ Order placed. ID: ${docRef.id}`);

      if (onOrderPlaced) onOrderPlaced();
    } catch (err) {
      setMessage("❌ Failed: " + err.message);
    }
  };

  return (
    <div
      style={{
        backgroundColor: "#1c1c1c",
        borderRadius: "12px",
        padding: "24px",
        width: "100%",
        maxWidth: "600px",
        maxHeight: "80vh",
        overflowY: "auto",
      }}
    >
      <input
        type="text"
        placeholder="Search menu item..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{
          width: "100%",
          padding: "10px",
          marginBottom: "16px",
          borderRadius: "8px",
          border: "1px solid #333",
          backgroundColor: "#111",
          color: "#fff",
        }}
      />

      {filteredItems.map((item) => (
        <div
          key={item.id}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "10px",
            border: "1px solid #333",
            borderRadius: "8px",
            padding: "10px",
          }}
        >
          <span>
            {item.name} — ₹{item.price}
          </span>
          <button
            onClick={() => addToCart(item)}
            style={{
              backgroundColor: "#FF7D00",
              color: "#fff",
              border: "none",
              padding: "6px 12px",
              borderRadius: "6px",
              cursor: "pointer",
            }}
          >
            ➕
          </button>
        </div>
      ))}

      <h4 style={{ marginTop: 20 }}>🛒 Cart</h4>
      {cart.map((item) => (
        <div
          key={item.id}
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: "10px",
            alignItems: "center",
          }}
        >
          <span>
            {item.name} — ₹{item.price} × {item.quantity}
          </span>
          <div>
            <button onClick={() => decreaseQty(item.id)}>➖</button>
            <button onClick={() => addToCart(item)}>➕</button>
            <button onClick={() => removeFromCart(item.id)}>❌</button>
          </div>
        </div>
      ))}

      {cart.length > 0 && (
        <>
          <h4>Total: ₹{getTotal()}</h4>
          <input
            type="text"
            placeholder="Customer name (optional)"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            style={{ width: "100%", marginBottom: 8, padding: "6px" }}
          />
          <input
            type="text"
            placeholder="Phone (optional)"
            value={customerPhone}
            onChange={(e) => setCustomerPhone(e.target.value)}
            style={{ width: "100%", marginBottom: 8, padding: "6px" }}
          />
          <label>
            <input
              type="checkbox"
              checked={paid}
              onChange={(e) => setPaid(e.target.checked)}
            />
            Mark as Paid
          </label>
          <br />
          <button
            onClick={placeOrder}
            style={{
              marginTop: 12,
              backgroundColor: "#FF7D00",
              color: "#fff",
              padding: "10px 20px",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              width: "100%",
            }}
          >
            ✅ Place Order
          </button>
        </>
      )}

      {message && <p style={{ marginTop: 12 }}>{message}</p>}
    </div>
  );
}

export default OrderPage;
