import React from "react";
import TodaySummary from "./TodaySummary";
import OrderPage from "./OrderPage";

function MainPage() {
  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>📊 Today at a Glance</h2>
        
      </div>

      <TodaySummary />

      <div style={{ marginTop: 40 }}>
        <h3>🛒 New Order</h3>
        <OrderPage onOrderPlaced={() => {}} />
      </div>
    </div>
  );
}

export default MainPage;
