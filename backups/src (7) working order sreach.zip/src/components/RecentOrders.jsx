import { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, onSnapshot } from "firebase/firestore";

function RecentOrders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "orders"), (snapshot) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const all = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      const todayOrders = all.filter(o => {
        const created = o.createdAt?.toDate?.() || new Date(o.createdAt);
        return created >= today;
      });

      setOrders(todayOrders.reverse()); // latest on top
    });

    return () => unsub();
  }, []);

  return (
    <div className="card">
      <h3>🕒 Recent Orders</h3>
      <ul style={{ fontSize: "14px", padding: 0, listStyle: "none" }}>
        {orders.slice(0, 6).map((order) => (
          <li key={order.id} style={{ marginBottom: "8px" }}>
            #{order.id.slice(-4)} — {order.customerName || "—"} — ₹{order.total}{" "}
            {order.paid && "✅"}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RecentOrders;
