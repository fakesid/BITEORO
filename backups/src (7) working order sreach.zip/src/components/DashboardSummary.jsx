// src/components/DashboardSummary.jsx
import { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, onSnapshot } from "firebase/firestore";

function DashboardSummary() {
  const [orders, setOrders] = useState([]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [paidTotal, setPaidTotal] = useState(0);
  const [unpaidTotal, setUnpaidTotal] = useState(0);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "orders"), (snapshot) => {
      const allOrders = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayOrders = allOrders.filter((order) => {
        const created = order.createdAt?.toDate?.() || new Date(order.createdAt);
        return (
          created.getFullYear() === today.getFullYear() &&
          created.getMonth() === today.getMonth() &&
          created.getDate() === today.getDate()
        );
      });

      setOrders(todayOrders);

      const total = todayOrders.reduce((sum, o) => sum + (o.total || 0), 0);
      const paid = todayOrders
        .filter((o) => o.paid)
        .reduce((sum, o) => sum + (o.total || 0), 0);
      const unpaid = total - paid;

      setTotalRevenue(total);
      setPaidTotal(paid);
      setUnpaidTotal(unpaid);
    });

    return () => unsub();
  }, []);

  return (
    <div>
      <h3>📊 Today’s Sales Summary</h3>
      <p>📦 Orders Today: {orders.length}</p>
      <p>✅ Paid: ₹{paidTotal} | ❌ Unpaid: ₹{unpaidTotal}</p>
      <p><strong>💰 Total Revenue: ₹{totalRevenue}</strong></p>

    
    </div>
  );
}

export default DashboardSummary;
