function StaffAccounts() {
  return (
    <div style={{ padding: "20px", color: "#fff" }}>
      <h2>👥 Staff Accounts</h2>
      <p>This is the Staff Account Management page.</p>
    </div>
  );
}

export default StaffAccounts;
