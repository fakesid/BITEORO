// src/pages/Home.jsx
function Customers() {
  return (
    <div>
      <h2>🏠 Dashboard (Home)</h2>
      <p>This will include New Order, Summary, and Recent Orders.</p>
    </div>
  );
}

export default Customers;
