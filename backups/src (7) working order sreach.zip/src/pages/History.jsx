// src/pages/History.jsx
function History() {
  return (
    <div>
      <h2>📜 Order History</h2>
      <p>This will show a list of all past orders, bills, and filters.</p>
    </div>
  );
}

export default History;
