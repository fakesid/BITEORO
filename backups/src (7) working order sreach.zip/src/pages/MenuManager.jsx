import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc
} from "firebase/firestore";

function MenuManager() {
  const [menuItems, setMenuItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: "", price: "", inStock: true });
  const [editingItemId, setEditingItemId] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    setMenuItems(items);
  };

  const handleAddItem = async () => {
    if (!newItem.name || !newItem.price) return;
    await addDoc(collection(db, "menu"), {
      ...newItem,
      price: parseFloat(newItem.price),
      inStock: !!newItem.inStock
    });
    setNewItem({ name: "", price: "", inStock: true });
    fetchMenu();
  };

  const handleDelete = async (id) => {
    await deleteDoc(doc(db, "menu", id));
    fetchMenu();
  };

  const handleUpdate = async (id, updated) => {
    await updateDoc(doc(db, "menu", id), updated);
    setEditingItemId(null);
    fetchMenu();
  };

  const toggleStyle = (on) => ({
    width: "40px",
    height: "20px",
    borderRadius: "12px",
    backgroundColor: on ? "#4CAF50" : "#F44336",
    position: "relative",
    cursor: "pointer",
    transition: "0.3s",
    marginLeft: "10px"
  });

  const knobStyle = (on) => ({
    position: "absolute",
    top: "2px",
    left: on ? "22px" : "2px",
    width: "16px",
    height: "16px",
    backgroundColor: "#fff",
    borderRadius: "50%",
    transition: "0.3s"
  });

  return (
    <div style={{ padding: 20 }}>
      <h2>📋 Menu Manager</h2>

      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Item name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
          style={{ padding: "10px", margin: "5px" }}
        />
        <input
          type="number"
          placeholder="Price"
          value={newItem.price}
          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
          style={{ padding: "10px", margin: "5px" }}
        />
        <div
          style={toggleStyle(newItem.inStock)}
          onClick={() =>
            setNewItem((prev) => ({ ...prev, inStock: !prev.inStock }))
          }
        >
          <div style={knobStyle(newItem.inStock)}></div>
        </div>
        <button onClick={handleAddItem} style={{ marginLeft: "10px" }}>
          ➕ Add Item
        </button>
      </div>

      <hr />

      <h3>📦 Menu Items</h3>
      {menuItems.map((item) => (
        <div
          key={item.id}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: "12px",
            padding: "10px",
            borderRadius: "8px",
            backgroundColor: "#1a1a1a"
          }}
        >
          {editingItemId === item.id ? (
            <>
              <input
                type="text"
                value={item.name}
                onChange={(e) =>
                  setMenuItems((prev) =>
                    prev.map((i) =>
                      i.id === item.id ? { ...i, name: e.target.value } : i
                    )
                  )
                }
              />
              <input
                type="number"
                value={item.price}
                onChange={(e) =>
                  setMenuItems((prev) =>
                    prev.map((i) =>
                      i.id === item.id ? { ...i, price: e.target.value } : i
                    )
                  )
                }
              />
              <div
                style={toggleStyle(item.inStock)}
                onClick={() =>
                  setMenuItems((prev) =>
                    prev.map((i) =>
                      i.id === item.id
                        ? { ...i, inStock: !i.inStock }
                        : i
                    )
                  )
                }
              >
                <div style={knobStyle(item.inStock)}></div>
              </div>
              <button onClick={() => handleUpdate(item.id, item)}>💾 Save</button>
              <button onClick={() => setEditingItemId(null)}>❌ Cancel</button>
            </>
          ) : (
            <>
              <div>
                🍔 <strong>{item.name}</strong> — ₹{item.price} —{" "}
                {item.inStock ? "✅ In Stock" : "❌ Out of Stock"}
              </div>
              <div style={{ display: "flex", gap: "8px" }}>
                <button onClick={() => setEditingItemId(item.id)}>✏️ Edit</button>
                <button onClick={() => handleDelete(item.id)}>🗑️ Delete</button>
              </div>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

export default MenuManager;
