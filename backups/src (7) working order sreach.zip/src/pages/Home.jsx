import { useState, useEffect } from "react";
import DashboardSummary from "../components/DashboardSummary";
import Modal from "../components/Modal";
import OrderPage from "../OrderPage";
import RecentOrders from "../components/RecentOrders";

function Home() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  // Lock scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = showOrderForm ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [showOrderForm]);

  return (
    <div>
      <div style={{ display: "flex", gap: "24px" }}>
        {/* Left side: summary and new order */}
        <div style={{ flex: 2 }}>
          <input
            type="text"
            placeholder="Search orders, customers, dates..."
            style={{
              padding: "10px",
              borderRadius: "5px",
              border: "1px solid #ccc",
              width: "100%",
              marginBottom: "20px"
            }}
          />

          <DashboardSummary />

          <div style={{ marginTop: 20 }}>
            <button onClick={() => setShowOrderForm(true)}>➕ New Order</button>
          </div>
        </div>

        {/* Right side: recent orders tab */}
        <div style={{ flex: 1, marginTop: "60px" }}>
          <RecentOrders />
        </div>
      </div>

      {/* Modal popup with OrderPage */}
      {showOrderForm && (
        <Modal onClose={() => setShowOrderForm(false)}>
          <OrderPage onOrderPlaced={() => setShowOrderForm(false)} />
        </Modal>
      )}

    </div>
  );
}

export default Home;
