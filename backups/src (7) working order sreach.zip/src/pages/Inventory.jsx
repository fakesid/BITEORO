function Inventory() {
  return (
    <div style={{ padding: "20px", color: "#fff" }}>
      <h2>📦 Inventory</h2>
      <p>This is the Inventory Management page.</p>
    </div>
  );
}

export default Inventory;
