// src/pages/Manage.jsx
function Manage() {
  return (
    <div>
      <h2>🛠️ Manage</h2>
      <p>This will include inventory, menu management, and staff accounts.</p>
    </div>
  );
}

export default Manage;
