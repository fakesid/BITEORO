// src/App.js
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Order from "./pages/Order";
import History from "./pages/History";
import Manage from "./pages/Manage";
import Customers from "./pages/Customers";
import './index.css'; // ensure this is included

function App() {
  return (
    <Router>
      <div style={{ display: "flex" }}>
        {/* Sidebar */}
        <aside className="sidebar">
          <Link to="/">🏠 Home</Link>
          <Link to="/order">🛒 New Order</Link>
          <Link to="/history">📜 Order History</Link>
          <Link to="/manage">🛠️ Manage</Link>
          <Link to="/customers">👥 Customers</Link>
        </aside>

        {/* Main Content */}
        <main className="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/order" element={<Order />} />
            <Route path="/history" element={<History />} />
            <Route path="/manage" element={<Manage />} />
            <Route path="/customers" element={<Customers />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
