import { useState } from "react";
import DashboardSummary from "../components/DashboardSummary";
import OrderPage from "../OrderPage";
import RecentOrders from "../components/RecentOrders";

function Home() {
  const [showOrderForm, setShowOrderForm] = useState(false);

  return (
    <div style={{ display: "flex", gap: "24px" }}>
      {/* Left side: summary and new order */}
      <div style={{ flex: 2 }}>
        <input
          type="text"
          placeholder="Search orders, customers, dates..."
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
            marginBottom: "20px"
          }}
        />

        <DashboardSummary />

        <div style={{ marginTop: 20 }}>
          <button onClick={() => setShowOrderForm(true)}>➕ New Order</button>
        </div>

        {showOrderForm && (
          <div className="card" style={{ marginTop: 12 }}>
            <OrderPage onOrderPlaced={() => setShowOrderForm(false)} />
          </div>
        )}
      </div>

      {/* Right side: recent orders tab */}
      <div style={{ flex: 1 }}>
        <RecentOrders />
      </div>
    </div>
  );
}

export default Home;
