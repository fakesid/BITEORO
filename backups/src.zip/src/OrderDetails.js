// src/OrderDetails.js

import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import {
  doc,
  getDoc,
  updateDoc
} from "firebase/firestore";

const OrderDetails = ({ orderId, onBack }) => {
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isPaid, setIsPaid] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editableItems, setEditableItems] = useState([]);

  useEffect(() => {
    fetchOrder();
  }, [orderId]);

  const fetchOrder = async () => {
    const ref = doc(db, "orders", orderId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data();
      setOrder(data);
      setIsPaid(data.paid);
      setEditableItems(data.items || []);
    }
    setLoading(false);
  };

  const togglePaid = async () => {
    const ref = doc(db, "orders", orderId);
    await updateDoc(ref, {
      paid: !isPaid
    });
    setIsPaid(!isPaid);
  };

  const handleQuantityChange = (index, value) => {
    const updatedItems = [...editableItems];
    updatedItems[index].quantity = parseInt(value) || 0;
    setEditableItems(updatedItems);
  };

  const removeItem = (index) => {
    const updatedItems = editableItems.filter((_, i) => i !== index);
    setEditableItems(updatedItems);
  };

  const saveChanges = async () => {
    const updatedTotal = editableItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
    const ref = doc(db, "orders", orderId);
    await updateDoc(ref, {
      items: editableItems,
      total: updatedTotal
    });
    setOrder({ ...order, items: editableItems, total: updatedTotal });
    setIsEditing(false);
  };

  if (loading) return <p>Loading...</p>;
  if (!order) return <p>Order not found</p>;

  return (
    <div style={{ padding: 20 }}>
      <button onClick={onBack}>⬅ Back</button>
      <h2>🧾 Order Details</h2>
      <p><b>Order ID:</b> {orderId}</p>
      <p><b>Customer:</b> {order.customerName || "N/A"}</p>
      <p><b>Phone:</b> {order.customerPhone || "N/A"}</p>
      <p><b>Status:</b> {isPaid ? "✅ Paid" : "❌ Unpaid"}</p>
      <button onClick={togglePaid}>
        {isPaid ? "Mark as Unpaid" : "Mark as Paid"}
      </button>

      {!isPaid && (
        <button onClick={() => setIsEditing(!isEditing)}>
          {isEditing ? "Cancel Edit" : "Edit Items"}
        </button>
      )}

      <h3>🛒 Items:</h3>
      <ul>
        {isEditing
          ? editableItems.map((item, i) => (
              <li key={i}>
                {item.name} – ₹{item.price} ×
                <input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => handleQuantityChange(i, e.target.value)}
                  style={{ width: 50, margin: "0 10px" }}
                />
                = ₹{item.price * item.quantity}
                <button onClick={() => removeItem(i)}>🗑</button>
              </li>
            ))
          : order.items?.map((item, i) => (
              <li key={i}>
                {item.name} – ₹{item.price} × {item.quantity} = ₹{item.price * item.quantity}
              </li>
            ))}
      </ul>

      <p><b>Total:</b> ₹{
        isEditing
          ? editableItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
          : order.total
      }</p>

      {isEditing && (
        <button onClick={saveChanges} style={{ marginTop: 10 }}>
          💾 Save Changes
        </button>
      )}
    </div>
  );
};

export default OrderDetails;
