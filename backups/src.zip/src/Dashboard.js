import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { collection, getDocs } from "firebase/firestore";

const Dashboard = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [topItems, setTopItems] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    const snapshot = await getDocs(collection(db, "orders"));
    const items = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data()
    }));
    setOrders(items);
    setLoading(false);
    calculateTopItems(items); // 👈 also process top items here
  };

  const today = new Date();
  const isToday = (date) => {
    const d = new Date(date);
    return (
      d.getDate() === today.getDate() &&
      d.getMonth() === today.getMonth() &&
      d.getFullYear() === today.getFullYear()
    );
  };

  const todayOrders = orders.filter((o) => {
    const created = o.createdAt?.toDate?.() || new Date(o.createdAt);
    return isToday(created);
  });

  const totalOrders = todayOrders.length;
  const totalItemsSold = todayOrders.reduce(
    (sum, order) =>
      sum + order.items.reduce((iSum, i) => iSum + i.quantity, 0),
    0
  );
  const totalRevenue = todayOrders.reduce((sum, order) => sum + order.total, 0);
  const paidAmount = todayOrders
    .filter((o) => o.paid)
    .reduce((sum, order) => sum + order.total, 0);
  const unpaidAmount = totalRevenue - paidAmount;

  const calculateTopItems = (allOrders) => {
    const allItems = [];
    allOrders.forEach((order) => {
      if (order.items && Array.isArray(order.items)) {
        order.items.forEach((item) => {
          allItems.push({ name: item.name, quantity: item.quantity });
        });
      }
    });

    const counts = {};
    allItems.forEach(({ name, quantity }) => {
      counts[name] = (counts[name] || 0) + quantity;
    });

    const sorted = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    setTopItems(sorted);
  };

  const getSalesByDay = () => {
    const dayMap = {};

    orders.forEach((order) => {
      const dateObj = order.createdAt?.toDate?.() || new Date(order.createdAt);
      const dayKey = dateObj.toISOString().split("T")[0]; // YYYY-MM-DD

      if (!dayMap[dayKey]) {
        dayMap[dayKey] = 0;
      }
      dayMap[dayKey] += order.total;
    });

    // Convert to array and sort by date descending
    return Object.entries(dayMap)
      .sort((a, b) => new Date(b[0]) - new Date(a[0]))
      .slice(0, 7);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>📊 Dashboard – {today.toDateString()}</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          <div>
            <p>🧾 Total Orders Today: <b>{totalOrders}</b></p>
            <p>📦 Items Sold Today: <b>{totalItemsSold}</b></p>
            <p>💰 Revenue Today: <b>₹{totalRevenue}</b></p>
            <p>✅ Paid: ₹{paidAmount}  ❌ Unpaid: ₹{unpaidAmount}</p>
          </div>

          <hr />

          <h3>🔥 Top Selling Items (All Time)</h3>
          <ul>
            {topItems.map(([name, qty], idx) => (
              <li key={idx}>
                {idx === 0 && "🥇"}
                {idx === 1 && "🥈"}
                {idx === 2 && "🥉"} {name} – {qty} sold
              </li>
            ))}
          </ul>

          <hr />

          <h3>📅 Sales – Last 7 Days</h3>
          <ul>
            {getSalesByDay().map(([date, revenue]) => (
              <li key={date}>
                {new Date(date).toLocaleDateString(undefined, {
                  weekday: "short",
                  day: "numeric",
                  month: "short"
                })}: ₹{revenue}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};

export default Dashboard;
