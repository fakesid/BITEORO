// src/CustomerList.js
import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { collection, getDocs } from "firebase/firestore";

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    const snapshot = await getDocs(collection(db, "orders"));
    const allOrders = snapshot.docs.map((doc) => doc.data());

    const customerMap = {};

    allOrders.forEach((order) => {
      const phone = order.customerPhone?.trim();
      if (!phone) return;

      if (!customerMap[phone]) {
        customerMap[phone] = {
          name: order.customerName || "N/A",
          phone,
          orderCount: 0,
          totalSpent: 0
        };
      }

      customerMap[phone].orderCount += 1;
      customerMap[phone].totalSpent += order.total;
    });

    const sorted = Object.values(customerMap).sort((a, b) => b.totalSpent - a.totalSpent);
    setCustomers(sorted);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>👥 Customer List</h2>
      {customers.length === 0 ? (
        <p>No customers with phone numbers found.</p>
      ) : (
        <table border="1" cellPadding="8" style={{ borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th>Phone</th>
              <th>Name</th>
              <th>Orders</th>
              <th>Total Spent</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c, idx) => (
              <tr key={idx}>
                <td>{c.phone}</td>
                <td>{c.name}</td>
                <td>{c.orderCount}</td>
                <td>₹{c.totalSpent}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default CustomerList;
