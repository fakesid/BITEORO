import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import {
  collection,
  getDocs,
  doc,
  getDoc
} from "firebase/firestore";
import OrderBill from "./OrderBill";
import OrderDetails from "./OrderDetails";

const OrderHistory = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [viewDetailsId, setViewDetailsId] = useState(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    const snapshot = await getDocs(collection(db, "orders"));
    const items = snapshot.docs
      .map((doc) => ({
        id: doc.id,
        ...doc.data()
      }))
      .filter((item) => item.createdAt && item.createdAt.toDate) // ✅ skip bad ones
      .sort((a, b) => b.createdAt.toDate() - a.createdAt.toDate()); // ✅ latest first

    setOrders(items);
    setLoading(false);
  };

  const formatDate = (createdAt) => {
    try {
      if (createdAt?.toDate) {
        return createdAt.toDate().toLocaleString();
      } else if (typeof createdAt === "string") {
        return new Date(createdAt).toLocaleString();
      }
    } catch {
      return "Invalid Date";
    }
    return "Unknown";
  };

  const loadOrderBill = async (orderId) => {
    try {
      const docRef = doc(db, "orders", orderId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        setSelectedOrder({ id: docSnap.id, ...data });
      } else {
        alert("Order not found.");
      }
    } catch (err) {
      console.error("Error loading bill:", err);
    }
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>📜 Order History</h2>

      <table border="1" cellPadding="10" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Total</th>
            <th>Paid</th>
            <th>Customer</th>
            <th>Time</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td>{order.id.slice(0, 8)}...</td>
              <td>₹{order.total}</td>
              <td>{order.paid ? "✅ Paid" : "❌ Unpaid"}</td>
              <td>{order.customerName || "N/A"}</td>
              <td>{formatDate(order.createdAt)}</td>
              <td>
                <button onClick={() => loadOrderBill(order.id)}>🧾 Bill</button>{" "}
                <button onClick={() => setViewDetailsId(order.id)}>🔍 Details</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedOrder && (
        <div style={{ marginTop: 30 }}>
          <h3>🧾 Selected Order Bill</h3>
          <OrderBill order={selectedOrder} />
          <button onClick={() => setSelectedOrder(null)} style={{ marginTop: 10 }}>
            ❌ Hide Bill
          </button>
        </div>
      )}

      {viewDetailsId && (
        <div style={{ marginTop: 30 }}>
          <OrderDetails
            orderId={viewDetailsId}
            onBack={() => setViewDetailsId(null)}
          />
        </div>
      )}
    </div>
  );
};

export default OrderHistory;
