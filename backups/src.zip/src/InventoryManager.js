// src/InventoryManager.js
import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  Timestamp
} from "firebase/firestore";

const InventoryManager = () => {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: "", quantity: "", unit: "", threshold: "" });
  const [editingId, setEditingId] = useState(null);
  const [restockNote, setRestockNote] = useState("");

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const snapshot = await getDocs(collection(db, "inventory"));
    const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    setItems(data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      name: form.name,
      quantity: parseFloat(form.quantity),
      unit: form.unit,
      threshold: parseFloat(form.threshold),
      lastUpdated: Timestamp.now(),
      notes: restockNote
    };

    if (editingId) {
      await updateDoc(doc(db, "inventory", editingId), payload);
    } else {
      await addDoc(collection(db, "inventory"), payload);
    }

    setForm({ name: "", quantity: "", unit: "", threshold: "" });
    setEditingId(null);
    setRestockNote("");
    fetchItems();
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this inventory item?")) {
      await deleteDoc(doc(db, "inventory", id));
      fetchItems();
    }
  };

  const handleEdit = (item) => {
    setForm({
      name: item.name,
      quantity: item.quantity,
      unit: item.unit,
      threshold: item.threshold
    });
    setRestockNote(item.notes || "");
    setEditingId(item.id);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>📦 Inventory Manager</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
        <input
          placeholder="Item name"
          value={form.name}
          required
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <input
          type="number"
          placeholder="Quantity"
          value={form.quantity}
          required
          onChange={(e) => setForm({ ...form, quantity: e.target.value })}
        />
        <input
          placeholder="Unit (e.g. kg, pcs)"
          value={form.unit}
          required
          onChange={(e) => setForm({ ...form, unit: e.target.value })}
        />
        <input
          type="number"
          placeholder="Low stock threshold"
          value={form.threshold}
          required
          onChange={(e) => setForm({ ...form, threshold: e.target.value })}
        />
        <input
          placeholder="Restock notes"
          value={restockNote}
          onChange={(e) => setRestockNote(e.target.value)}
        />
        <button type="submit">{editingId ? "Update" : "Add Item"}</button>
        {editingId && (
          <button onClick={() => { setEditingId(null); setForm({ name: "", quantity: "", unit: "", threshold: "" }); }}>Cancel</button>
        )}
      </form>

      <table border="1" cellPadding="10" style={{ borderCollapse: "collapse", width: "100%" }}>
        <thead>
          <tr>
            <th>Name</th>
            <th>Qty</th>
            <th>Unit</th>
            <th>Threshold</th>
            <th>Last Updated</th>
            <th>Note</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const isLow = item.quantity < item.threshold;
            return (
              <tr key={item.id} style={{ backgroundColor: isLow ? "#ffe5e5" : "white" }}>
                <td>{item.name}</td>
                <td>{item.quantity}</td>
                <td>{item.unit}</td>
                <td>{item.threshold}</td>
                <td>{item.lastUpdated?.toDate?.().toLocaleString() || "-"}</td>
                <td>{item.notes || "-"}</td>
                <td>
                  <button onClick={() => handleEdit(item)}>✏️</button>{" "}
                  <button onClick={() => handleDelete(item.id)}>🗑️</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default InventoryManager;
