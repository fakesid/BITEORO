import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyATdrT65tFd7UR1pdq8W5_me9UxCeqhy64",
  authDomain: "cafeapp-aa6ab.firebaseapp.com",
  projectId: "cafeapp-aa6ab",
  storageBucket: "cafeapp-aa6ab.appspot.com",
  messagingSenderId: "333774956015",
  appId: "1:333774956015:web:c1af0a805f57be39cac21a"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { app, db };
