// Clock.js
import React, { useEffect, useState } from "react";

const Clock = () => {
  const [date, setDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setDate(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const time = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const day = date.toLocaleDateString('en-US', { weekday: 'long' });
  const fullDate = date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  return (
    <div style={styles.container}>
      <div style={styles.time}>{time}</div>
      <div style={styles.day}>{day}</div>
      <div style={styles.date}>{fullDate}</div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: '20px',
    padding: '20px 40px',
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
    fontFamily: 'monospace',
    width: 'fit-content',
    margin: '0 auto'
  },
  time: {
    fontSize: '3rem',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px'
  },
  day: {
    fontSize: '1.2rem',
    color: '#666',
    marginBottom: '4px'
  },
  date: {
    fontSize: '1rem',
    color: '#999'
  }
};

export default Clock;
