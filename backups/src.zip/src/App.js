import React, { useState } from "react";
import OrderPage from "./OrderPage";
import MenuManager from "./MenuManager";
import OrderHistory from "./OrderHistory";
import Dashboard from "./Dashboard";
import CustomerList from "./CustomerList";
import InventoryManager from "./InventoryManager";
import MainPage from "./MainPage"; // ✅ NEW

function App() {
  const [view, setView] = useState("main"); // ✅ Default to Main Page

  return (
    <div style={{ padding: 20 }}>
      <nav>
        <button onClick={() => setView("main")}>🏠 Home</button>{" "} {/* ✅ New button */}
        <button onClick={() => setView("order")}>🛒 New Order</button>{" "}
        <button onClick={() => setView("menu")}>🍔 Menu Manager</button>{" "}
        <button onClick={() => setView("history")}>📜 Order History</button>{" "}
        <button onClick={() => setView("dashboard")}>📊 Dashboard</button>{" "}
        <button onClick={() => setView("customers")}>👥 Customers</button>
        <button onClick={() => setView("inventory")}>📦 Inventory</button>
      </nav>
      <hr />
      {view === "main" && <MainPage startNewOrder={() => setView("order")} />} {/* ✅ */}
      {view === "order" && <OrderPage />}
      {view === "menu" && <MenuManager />}
      {view === "history" && <OrderHistory />}
      {view === "dashboard" && <Dashboard />}
      {view === "customers" && <CustomerList />}
      {view === "inventory" && <InventoryManager />}
    </div>
  );
}

export default App;
