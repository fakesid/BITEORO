import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { collection, onSnapshot } from "firebase/firestore";
import OrderBill from "./OrderBill";

function TodaySummary() {
  const [todaysOrders, setTodaysOrders] = useState([]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [paidTotal, setPaidTotal] = useState(0);
  const [unpaidTotal, setUnpaidTotal] = useState(0);
  const [expandedOrderId, setExpandedOrderId] = useState(null); // 🔄 Toggle logic

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "orders"), (snapshot) => {
      const allOrders = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data()
      }));

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayOrders = allOrders.filter((order) => {
        const created = order.createdAt?.toDate?.() || new Date(order.createdAt);
        return (
          created.getFullYear() === today.getFullYear() &&
          created.getMonth() === today.getMonth() &&
          created.getDate() === today.getDate()
        );
      });

      setTodaysOrders(todayOrders);

      const total = todayOrders.reduce((sum, o) => sum + (o.total || 0), 0);
      const paid = todayOrders
        .filter((o) => o.paid)
        .reduce((sum, o) => sum + (o.total || 0), 0);
      const unpaid = total - paid;

      setTotalRevenue(total);
      setPaidTotal(paid);
      setUnpaidTotal(unpaid);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div>
      <div style={{ marginTop: 20 }}>
        <p><strong>Total Orders:</strong> {todaysOrders.length}</p>
        <p><strong>Revenue:</strong> ₹{totalRevenue}</p>
        <p>✅ Paid: ₹{paidTotal} &nbsp; ❌ Unpaid: ₹{unpaidTotal}</p>
      </div>

      <h3 style={{ marginTop: 30 }}>📋 Recent Orders Today</h3>
      <ul>
        {todaysOrders.map((order) => (
          <li
            key={order.id}
            style={{
              marginBottom: 12,
              borderBottom: "1px solid #ccc",
              paddingBottom: 10
            }}
          >
            <div><strong>ID:</strong> {order.id}</div>
            <div><strong>Customer:</strong> {order.customerName || "N/A"}</div>
            <div><strong>Items:</strong> {order.items?.map(i => i.name).join(", ")}</div>
            <div><strong>Total:</strong> ₹{order.total} | {order.paid ? "✅ Paid" : "❌ Unpaid"}</div>
            <div><small>{order.createdAt?.toDate?.().toLocaleString()}</small></div>

            <button
              onClick={() =>
                setExpandedOrderId(order.id === expandedOrderId ? null : order.id)
              }
              style={{ marginTop: 5 }}
            >
              {order.id === expandedOrderId ? "🔽 Hide Bill" : "🧾 View Bill"}
            </button>

            {order.id === expandedOrderId && (
              <div style={{ marginTop: 10 }}>
                <OrderBill order={order} showInline={true} />
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodaySummary;
