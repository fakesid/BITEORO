import React, { useState, useEffect } from "react";
import { db } from "./firebase";
import OrderBill from "./OrderBill";
import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp,
  Timestamp
} from "firebase/firestore";

function App() {
  const [menuItems, setMenuItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState([]);
  const [ordering, setOrdering] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paid, setPaid] = useState(false);
  const [message, setMessage] = useState("");
  const [lastOrder, setLastOrder] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data()
    }));
    setMenuItems(items);
  };

  const filteredItems = menuItems.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToCart = (item) => {
    if (!item.inStock) {
      setMessage(`❌ ${item.name} is out of stock.`);
      return;
    }

    const exists = cart.find((i) => i.id === item.id);
    if (exists) {
      setCart(
        cart.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      );
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const decreaseQty = (id) => {
    const item = cart.find((i) => i.id === id);
    if (item.quantity === 1) {
      removeFromCart(id);
    } else {
      setCart(
        cart.map((i) =>
          i.id === id ? { ...i, quantity: item.quantity - 1 } : i
        )
      );
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const getTotal = () =>
    cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const placeOrder = async () => {
    if (cart.length === 0) {
      setMessage("❌ Cart is empty");
      return;
    }

    try {
      const docRef = await addDoc(collection(db, "orders"), {
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        paymentMode: paid ? "cash" : null,
        createdAt: serverTimestamp(),
        status: "new"
      });

      setLastOrder({
        id: docRef.id,
        customerName,
        customerPhone,
        items: cart,
        total: getTotal(),
        paid,
        createdAt: Timestamp.now()
      });

      setCart([]);
      setCustomerName("");
      setCustomerPhone("");
      setPaid(false);
      setOrdering(false);
      setSearchTerm("");
      setMessage(`✅ Order placed successfully. Order ID: ${docRef.id}`);
    } catch (err) {
      setMessage("❌ Failed: " + err.message);
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 700, margin: "auto" }}>
      <h2>Simple Cafe Ordering System</h2>

      {!ordering ? (
        <button
          onClick={() => {
            setOrdering(true);
            setMessage("");
            setLastOrder(null);
          }}
        >
          ➕ New Order
        </button>
      ) : (
        <>
          <input
            type="text"
            placeholder="Search menu item..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ width: "100%", padding: 8, marginBottom: 10 }}
          />

          {searchTerm && filteredItems.length > 0 ? (
            filteredItems.map((item) => (
              <div key={item.id}>
                {item.name} – ₹{item.price}{" "}
                {item.inStock ? (
                  <button onClick={() => addToCart(item)}>➕</button>
                ) : (
                  <span style={{ color: "red" }}>Out of Stock</span>
                )}
              </div>
            ))
          ) : searchTerm ? (
            <p>No matching items found.</p>
          ) : null}

          <hr />

          <h3>🛒 Cart</h3>
          {cart.length === 0 && <p>No items in cart.</p>}
          {cart.map((item) => (
            <div key={item.id}>
              <strong>{item.name}</strong> – ₹{item.price} × {item.quantity} = ₹
              {item.price * item.quantity}{" "}
              <button onClick={() => decreaseQty(item.id)}>➖</button>{" "}
              <button onClick={() => addToCart(item)}>➕</button>{" "}
              <button onClick={() => removeFromCart(item.id)}>❌</button>
            </div>
          ))}

          {cart.length > 0 && (
            <>
              <h4>Total: ₹{getTotal()}</h4>

              <input
                type="text"
                placeholder="Customer name (optional)"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
              <br />
              <input
                type="text"
                placeholder="Phone (optional)"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
              />
              <br />
              <label>
                <input
                  type="checkbox"
                  checked={paid}
                  onChange={(e) => setPaid(e.target.checked)}
                />
                Mark as Paid
              </label>
              <br />
              <button onClick={placeOrder}>✅ Place Order</button>{" "}
              <button onClick={() => setOrdering(false)}>❌ Cancel</button>
            </>
          )}
        </>
      )}

      {message && <p>{message}</p>}
      {lastOrder && <OrderBill order={lastOrder} />}
    </div>
  );
}

export default App;
