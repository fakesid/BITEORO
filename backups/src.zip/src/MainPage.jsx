import React from "react";
import TodaySummary from "./TodaySummary";
import OrderPage from "./OrderPage";
import Clock from "./Clock"; // Import the new clock component

function MainPage() {
  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>📊 Today at a Glance</h2>
        <Clock /> {/* ⏰ Simple Digital Clock */}
      </div>

      <TodaySummary />

      <div style={{ marginTop: 40 }}>
        <h3>🛒 New Order</h3>
        <OrderPage onOrderPlaced={() => {}} />
      </div>
    </div>
  );
}

export default MainPage;
