import React, { useState, useEffect } from "react";
import { db } from "./firebase";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc
} from "firebase/firestore";

function MenuManager() {
  const [menuItems, setMenuItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: "", price: "", inStock: true });
  const [editingItemId, setEditingItemId] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const snapshot = await getDocs(collection(db, "menu"));
    const items = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    setMenuItems(items);
  };

  const handleAddItem = async () => {
    if (!newItem.name || !newItem.price) return;
    await addDoc(collection(db, "menu"), {
      ...newItem,
      price: parseFloat(newItem.price),
      inStock: !!newItem.inStock
    });
    setNewItem({ name: "", price: "", inStock: true });
    fetchMenu();
  };

  const handleDelete = async (id) => {
    await deleteDoc(doc(db, "menu", id));
    fetchMenu();
  };

  const handleUpdate = async (id, updated) => {
    await updateDoc(doc(db, "menu", id), updated);
    setEditingItemId(null);
    fetchMenu();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>📋 Menu Manager</h2>

      <div>
        <input
          type="text"
          placeholder="Item name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        />
        <input
          type="number"
          placeholder="Price"
          value={newItem.price}
          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
        />
        <label>
          <input
            type="checkbox"
            checked={newItem.inStock}
            onChange={(e) => setNewItem({ ...newItem, inStock: e.target.checked })}
          />
          In Stock
        </label>
        <button onClick={handleAddItem}>➕ Add Item</button>
      </div>

      <hr />

      <h3>📦 Current Menu</h3>
      {menuItems.map((item) => (
        <div key={item.id}>
          {editingItemId === item.id ? (
            <>
              <input
                type="text"
                value={item.name}
                onChange={(e) =>
                  setMenuItems((prev) =>
                    prev.map((i) =>
                      i.id === item.id ? { ...i, name: e.target.value } : i
                    )
                  )
                }
              />
              <input
                type="number"
                value={item.price}
                onChange={(e) =>
                  setMenuItems((prev) =>
                    prev.map((i) =>
                      i.id === item.id ? { ...i, price: e.target.value } : i
                    )
                  )
                }
              />
              <label>
                <input
                  type="checkbox"
                  checked={item.inStock}
                  onChange={(e) =>
                    setMenuItems((prev) =>
                      prev.map((i) =>
                        i.id === item.id
                          ? { ...i, inStock: e.target.checked }
                          : i
                      )
                    )
                  }
                />
                In Stock
              </label>
              <button onClick={() => handleUpdate(item.id, item)}>💾 Save</button>
              <button onClick={() => setEditingItemId(null)}>❌ Cancel</button>
            </>
          ) : (
            <>
              🍔 <strong>{item.name}</strong> — ₹{item.price} —{" "}
              {item.inStock ? "✅ In Stock" : "❌ Out of Stock"}
              <button onClick={() => setEditingItemId(item.id)}>✏️ Edit</button>
              <button onClick={() => handleDelete(item.id)}>🗑️ Delete</button>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

export default MenuManager;
